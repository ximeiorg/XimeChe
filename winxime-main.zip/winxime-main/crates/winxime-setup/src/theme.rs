use gpui::*;

#[derive(Clone)]
pub enum SystemTheme {
    Light,
    Dark,
}

impl SystemTheme {
    pub fn detect() -> Self {
        #[cfg(windows)]
        {
            use windows::core::w;
            use windows::Win32::System::Registry::*;

            let key_path = w!("Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize");
            let value_name = w!("AppsUseLightTheme");

            let mut handle = HKEY::default();

            if unsafe {
                RegOpenKeyExW(HKEY_CURRENT_USER, key_path, Some(0), KEY_READ, &mut handle).is_ok()
            } {
                let mut data: u32 = 0;
                let mut data_size: u32 = 4;

                let result = unsafe {
                    RegQueryValueExW(
                        handle,
                        value_name,
                        None,
                        None,
                        Some(&mut data as *mut _ as *mut u8),
                        Some(&mut data_size),
                    )
                };

                unsafe {
                    let _ = RegCloseKey(handle);
                };

                if result.is_ok() {
                    if data == 0 {
                        return SystemTheme::Dark;
                    }
                }
            }
        }

        SystemTheme::Light
    }

    pub fn is_dark(&self) -> bool {
        matches!(self, SystemTheme::Dark)
    }
}

#[derive(Clone)]
pub struct ThemeColors {
    pub background: Hsla,
    pub surface: Hsla,
    pub surface_variant: Hsla,
    pub primary: Hsla,
    pub primary_hover: Hsla,
    pub on_primary: Hsla,
    pub sidebar_bg: Hsla,
    pub foreground: Hsla,
    pub foreground_muted: Hsla,
    pub border: Hsla,
    pub border_variant: Hsla,
    pub disabled: Hsla,
    pub error: Hsla,
    pub on_error: Hsla,
    pub selection: Hsla,
}

impl ThemeColors {
    pub fn from_theme(theme: &SystemTheme, primary_color: u32) -> Self {
        let (r, g, b) = (
            (primary_color >> 16) as u8,
            (primary_color >> 8) as u8,
            primary_color as u8,
        );
        let hover_r = (r as f32 * 0.9) as u8;
        let hover_g = (g as f32 * 0.9) as u8;
        let hover_b = (b as f32 * 0.9) as u8;
        let primary_hover = ((hover_r as u32) << 16) | ((hover_g as u32) << 8) | hover_b as u32;

        let sidebar_r = (r as f32 * 0.35) as u8;
        let sidebar_g = (g as f32 * 0.35) as u8;
        let sidebar_b = (b as f32 * 0.35) as u8;
        let sidebar_bg = ((sidebar_r as u32) << 16) | ((sidebar_g as u32) << 8) | sidebar_b as u32;

        let selection_r = (r as f32 * 0.15 + 255.0 * 0.85) as u8;
        let selection_g = (g as f32 * 0.15 + 255.0 * 0.85) as u8;
        let selection_b = (b as f32 * 0.15 + 255.0 * 0.85) as u8;
        let selection_light =
            ((selection_r as u32) << 16) | ((selection_g as u32) << 8) | selection_b as u32;

        let selection_dark_r = (r as f32 * 0.3) as u8;
        let selection_dark_g = (g as f32 * 0.3) as u8;
        let selection_dark_b = (b as f32 * 0.3) as u8;
        let selection_dark = ((selection_dark_r as u32) << 16)
            | ((selection_dark_g as u32) << 8)
            | selection_dark_b as u32;

        if theme.is_dark() {
            Self {
                background: hsla(0.0, 0.0, 0.05, 0.85),
                surface: rgb(0x1a1a1a).into(),
                surface_variant: rgb(0x262626).into(),
                primary: rgb(primary_color).into(),
                primary_hover: rgb(primary_hover).into(),
                on_primary: rgb(0xffffff).into(),
                sidebar_bg: rgb(sidebar_bg).into(),
                foreground: rgb(0xe0e0e0).into(),
                foreground_muted: rgb(0x808080).into(),
                border: rgb(0x303030).into(),
                border_variant: rgb(0x404040).into(),
                disabled: rgb(0x4d4d4d).into(),
                error: rgb(0xc42b1c).into(),
                on_error: rgb(0xffffff).into(),
                selection: rgb(selection_dark).into(),
            }
        } else {
            Self {
                background: hsla(0.0, 0.0, 1.0, 0.95),
                surface: rgb(0xffffff).into(),
                surface_variant: rgb(0xf5f5f5).into(),
                primary: rgb(primary_color).into(),
                primary_hover: rgb(primary_hover).into(),
                on_primary: rgb(0xffffff).into(),
                sidebar_bg: rgb(sidebar_bg).into(),
                foreground: rgb(0x1a1a1a).into(),
                foreground_muted: rgb(0x666666).into(),
                border: rgb(0xe0e0e0).into(),
                border_variant: rgb(0xd0d0d0).into(),
                disabled: rgb(0xaaaaaa).into(),
                error: rgb(0xc42b1c).into(),
                on_error: rgb(0xffffff).into(),
                selection: rgb(selection_light).into(),
            }
        }
    }
}
